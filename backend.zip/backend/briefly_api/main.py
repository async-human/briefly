from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from briefly_api.api.router import api_router
from briefly_api.config import get_settings
from briefly_api.db.engine import init_db
from briefly_api.ingestion.smtp_server import start_smtp_server
from briefly_api.workers.scheduler import digest_scheduler_loop

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(_app: FastAPI):
    try:
        await init_db()
    except Exception:
        logger.exception("Database startup failed — check DATABASE_URL and Supabase SSL/password")
        raise

    scheduler_task = asyncio.create_task(digest_scheduler_loop())
    logger.info("Digest scheduler started")

    settings = get_settings()
    smtp_controller = start_smtp_server(settings)

    yield

    scheduler_task.cancel()
    try:
        await scheduler_task
    except asyncio.CancelledError:
        pass
    logger.info("Digest scheduler stopped")

    if smtp_controller:
        smtp_controller.stop()
        logger.info("SMTP ingestion server stopped")


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(title=settings.app_name, lifespan=lifespan)

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origin_list,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.get("/health")
    async def health() -> dict[str, str]:
        return {"status": "ok"}

    app.include_router(api_router)
    return app


app = create_app()
