from __future__ import annotations

import secrets

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from briefly_api.auth.jwt import decode_access_token
from briefly_api.config import Settings, get_settings
from briefly_api.db.engine import get_db
from briefly_api.db.models import User

_bearer = HTTPBearer(auto_error=False)


async def get_current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(_bearer),
    db: AsyncSession = Depends(get_db),
    settings: Settings = Depends(get_settings),
) -> User:
    if credentials is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated")

    user_id = decode_access_token(credentials.credentials, settings)
    if not user_id:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token")

    result = await db.execute(
        select(User)
        .options(selectinload(User.profile))
        .where(User.id == user_id, User.is_active.is_(True))
    )
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User not found")
    return user


async def get_capture_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(_bearer),
    db: AsyncSession = Depends(get_db),
    settings: Settings = Depends(get_settings),
) -> User:
    """
    Auth for capture endpoints: accepts either a normal session JWT (web app,
    browser extension) or a long-lived capture device token (mobile share
    extension, iOS Shortcut, PWA). Lets every client hit /capture/* the same way.
    """
    if credentials is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated")

    from briefly_api.services import capture_tokens

    token = credentials.credentials
    if capture_tokens.looks_like_capture_token(token):
        user = await capture_tokens.resolve_user(db, token)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid or revoked capture token",
            )
        return user

    # Fall back to the standard session-JWT path.
    user_id = decode_access_token(token, settings)
    if not user_id:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token")

    result = await db.execute(
        select(User)
        .options(selectinload(User.profile))
        .where(User.id == user_id, User.is_active.is_(True))
    )
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User not found")
    return user


async def resolve_capture_user_from_token(db: AsyncSession, token: str) -> User | None:
    """Resolve a user from a capture token or session JWT (for WebSocket auth)."""
    from briefly_api.services import capture_tokens

    raw = (token or "").strip()
    if not raw:
        return None
    if capture_tokens.looks_like_capture_token(raw):
        return await capture_tokens.resolve_user(db, raw)
    settings = get_settings()
    user_id = decode_access_token(raw, settings)
    if not user_id:
        return None
    result = await db.execute(
        select(User)
        .options(selectinload(User.profile))
        .where(User.id == user_id, User.is_active.is_(True))
    )
    return result.scalar_one_or_none()


def generate_email_token() -> str:
    return secrets.token_hex(16)
