"""Persist live-fetched pipeline items into raw_contents so digest FK links succeed."""
from __future__ import annotations

import logging

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from briefly_api.agents.context import PipelineContext, RawItem
from briefly_api.db.models import ContentStatus, RawContent

log = logging.getLogger(__name__)


def _apply_row_update(existing: RawContent, item: RawItem, user_id: str) -> None:
    existing.title = item.title
    existing.url = item.url
    existing.author = item.author
    existing.published_at = item.published_at
    existing.clean_text = item.clean_text
    existing.summary = item.summary or item.clean_text[:400]
    existing.content_hash = item.content_hash or existing.content_hash
    existing.relevance_score = item.relevance_score or existing.relevance_score
    existing.status = ContentStatus.pending
    existing.user_id = user_id
    existing.meta = {**(existing.meta or {}), **(item.meta or {}), "live_fetch": True}


async def _find_existing_row(
    session: AsyncSession,
    item: RawItem,
) -> RawContent | None:
    """Match by primary key first, then the (source_id, content_hash) unique key."""
    if item.id:
        row = await session.get(RawContent, item.id)
        if row:
            return row

    if not item.source_id or not item.content_hash:
        return None

    result = await session.execute(
        select(RawContent).where(
            RawContent.source_id == item.source_id,
            RawContent.content_hash == item.content_hash,
        )
    )
    return result.scalar_one_or_none()


async def persist_live_raw_items(
    session: AsyncSession,
    user_id: str,
    items: list[RawItem],
) -> None:
    """
    Upsert live-fetched RawItems into raw_contents.
    Remaps item.id to the existing DB row when content_hash already exists so
    digest_items.content_id FK references stay valid.
    """
    if not items:
        return

    live = [i for i in items if not i.meta.get("from_pool")]
    if not live:
        return

    persisted = 0
    pending_keys: set[tuple[str, str]] = set()
    for item in live:
        item.meta["live_fetch"] = True
        if not item.source_id:
            log.debug("Skipping live persist — no source_id for %r", (item.title or "")[:60])
            continue

        batch_key = (item.source_id, item.content_hash or "")
        if batch_key in pending_keys:
            continue
        pending_keys.add(batch_key)

        existing = await _find_existing_row(session, item)
        if existing:
            item.id = existing.id
            _apply_row_update(existing, item, user_id)
            persisted += 1
            continue

        session.add(
            RawContent(
                id=item.id,
                source_id=item.source_id,
                user_id=user_id,
                status=ContentStatus.pending,
                title=item.title,
                url=item.url,
                author=item.author,
                published_at=item.published_at,
                clean_text=item.clean_text,
                summary=item.summary or item.clean_text[:400],
                content_hash=item.content_hash,
                relevance_score=item.relevance_score or None,
                meta={**(item.meta or {}), "live_fetch": True},
            )
        )
        persisted += 1

    try:
        await session.flush()
    except IntegrityError as exc:
        await session.rollback()
        log.warning(
            "Live pool persist hit duplicate content — retrying row-by-row: %s",
            exc.orig if hasattr(exc, "orig") else exc,
        )
        await _persist_live_raw_items_safe(session, user_id, live)
        return

    log.info("Persisted %d live item(s) to raw_contents for user %s", persisted, user_id)


async def _persist_live_raw_items_safe(
    session: AsyncSession,
    user_id: str,
    live: list[RawItem],
) -> None:
    """Row-by-row upsert fallback when a batch flush hits uq_content."""
    saved = 0
    for item in live:
        if not item.source_id:
            log.debug("Skipping live persist — no source_id for %r", (item.title or "")[:60])
            continue
        item.meta["live_fetch"] = True
        try:
            existing = await _find_existing_row(session, item)
            if existing:
                item.id = existing.id
                _apply_row_update(existing, item, user_id)
            else:
                session.add(
                    RawContent(
                        id=item.id,
                        source_id=item.source_id,
                        user_id=user_id,
                        status=ContentStatus.pending,
                        title=item.title,
                        url=item.url,
                        author=item.author,
                        published_at=item.published_at,
                        clean_text=item.clean_text,
                        summary=item.summary or item.clean_text[:400],
                        content_hash=item.content_hash,
                        relevance_score=item.relevance_score or None,
                        meta={**(item.meta or {}), "live_fetch": True},
                    )
                )
            await session.flush()
            saved += 1
        except IntegrityError:
            await session.rollback()
            existing = await _find_existing_row(session, item)
            if existing:
                item.id = existing.id
                _apply_row_update(existing, item, user_id)
                await session.flush()
                saved += 1
            else:
                log.warning(
                    "Could not persist live item %r — remapping by content_hash failed",
                    (item.title or "")[:60],
                )

    log.info("Persisted %d live item(s) to raw_contents (safe mode) for user %s", saved, user_id)


async def ensure_digest_content_links(session: AsyncSession, ctx: PipelineContext) -> None:
    """Safety net: upsert raw_contents rows for digest items before FK insert."""
    selected_ids = {d.content_id for d in ctx.digest_items if d.content_id}
    if not selected_ids:
        return

    by_id = {i.id: i for i in ctx.enriched_items}
    to_persist = [by_id[iid] for iid in selected_ids if iid in by_id]
    if not to_persist:
        return

    await persist_live_raw_items(session, ctx.user.user_id, to_persist)
    await session.flush()
