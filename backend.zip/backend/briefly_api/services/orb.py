"""
briefly_api/services/orb.py

Orchestration for the voice orb. One "turn" is: audio in → STT → route to a tool
(or the Ask Briefly brain) → text answer + citations. The client plays the
answer via /orb/speak (TTS) so playback streams independently of reasoning.

Routing is fast by default. Tools are declared once in `orb_tools.py`; here we
only decide *which* to run:

  - exactly one tool's fast-pattern matches  → run it directly (no planner call)
  - no tool matches (an open question)        → Ask Briefly directly (no planner)
  - two or more tools match (mixed intent)    → LLM planner decides + synthesizes

So the planner LLM round-trip — pure overhead on the common path — only happens
for genuinely ambiguous multi-intent turns. STT + brain are the only LLM hops
for the everyday "answer my question" / "read my brief" cases.

Everything reuses provider-agnostic pieces: STT (stt.adapter), brain
(ask_briefly), TTS (tts.adapter via the /orb/speak route).
"""
from __future__ import annotations

import json
import logging
import re
import time
import uuid
from collections.abc import AsyncIterator
from datetime import datetime, timezone

import httpx
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from briefly_api.db.engine import SessionLocal

from briefly_api.agent import AgentRuntime, ToolContext, ToolRegistry, from_orb_tool
from briefly_api.config import get_settings
from briefly_api.db.models import FollowUpThread, User
from briefly_api.llm.adapter import Message, get_llm_adapter
from briefly_api.services.ask_briefly import ask_briefly, iter_ask_briefly_events
from briefly_api.services.orb_router import route_transcript
from briefly_api.services.orb_session import (
    OrbSessionState,
    resolve_session,
    update_session_after_turn,
)
from briefly_api.services.orb_tools import DATA_TOOLS, OrbTool
from briefly_api.stt.adapter import get_stt_adapter

log = logging.getLogger(__name__)

_MAX_TOOL_STEPS = 3


# ── Ask Briefly as a registry tool ───────────────────────────────────────────
# Defined here (not in orb_tools) so it calls the module-level `ask_briefly`,
# which tests monkeypatch and which is the single source of brain behaviour.


async def _ask_handler(
    db: AsyncSession,
    user: User,
    *,
    transcript: str,
    thread_id: str | None = None,
    content_id: str | None = None,
    args: dict | None = None,
) -> dict:
    result = await ask_briefly(
        db, user, transcript, thread_id=thread_id, content_id=content_id, voice=True
    )
    assistant = result.get("assistant", {}) if isinstance(result, dict) else {}
    return {
        "answer": assistant.get("content", ""),
        "citations": assistant.get("citations", []),
        "thread_id": result.get("thread_id") if isinstance(result, dict) else None,
    }


ASK_TOOL = OrbTool(
    name="ask_briefly",
    description="General-purpose question answering over the user's corpus, with citations.",
    handler=_ask_handler,
)

REGISTRY: list[OrbTool] = [*DATA_TOOLS, ASK_TOOL]
_BY_NAME: dict[str, OrbTool] = {t.name: t for t in REGISTRY}


# ── Execution helpers ────────────────────────────────────────────────────────


async def _exec_tool(
    tool: OrbTool,
    db: AsyncSession,
    user: User,
    transcript: str,
    thread_id: str | None,
    content_id: str | None,
    args: dict | None = None,
) -> dict:
    out = await tool.handler(
        db, user, transcript=transcript, thread_id=thread_id, content_id=content_id, args=args
    )
    return {"tool": tool.name, **out}


def _merge_citations(tool_outputs: list[dict]) -> list[dict]:
    seen: set[tuple[str, str]] = set()
    merged: list[dict] = []
    for out in tool_outputs:
        for c in out.get("citations", []) or []:
            key = (str(c.get("content_id") or ""), str(c.get("title") or ""))
            if key in seen:
                continue
            seen.add(key)
            merged.append(c)
    return merged


def _tool_trace(tool_outputs: list[dict]) -> list[dict]:
    return [
        {
            "tool": out.get("tool"),
            "answer_chars": len(str(out.get("answer") or "")),
            "citations_count": len(out.get("citations") or []),
        }
        for out in tool_outputs
    ]


async def _thread_message_count(
    db: AsyncSession,
    user_id: str,
    thread_id: str | None,
) -> int:
    if not thread_id:
        return 0
    result = await db.execute(
        select(FollowUpThread).where(
            FollowUpThread.id == thread_id,
            FollowUpThread.user_id == user_id,
        )
    )
    thread = result.scalar_one_or_none()
    if not thread:
        return 0
    return len(thread.messages or [])


async def _persist_orb_exchange(
    db: AsyncSession,
    user_id: str,
    thread_id: str | None,
    user_text: str,
    assistant_text: str,
    *,
    citations: list | None = None,
) -> str | None:
    """Append a voice turn to FollowUpThread so follow-ups retain context."""
    answer = (assistant_text or "").strip()
    question = (user_text or "").strip()
    if not answer or not question:
        return thread_id

    now = datetime.now(timezone.utc).isoformat()
    thread: FollowUpThread | None = None
    if thread_id:
        result = await db.execute(
            select(FollowUpThread).where(
                FollowUpThread.id == thread_id,
                FollowUpThread.user_id == user_id,
            )
        )
        thread = result.scalar_one_or_none()

    if thread is None:
        thread = FollowUpThread(
            id=str(uuid.uuid4()),
            user_id=user_id,
            messages=[],
        )
        db.add(thread)

    thread.messages = list(thread.messages or []) + [
        {"role": "user", "content": question, "timestamp": now},
        {
            "role": "assistant",
            "content": answer,
            "citations": citations or [],
            "timestamp": now,
        },
    ]
    await db.commit()
    await db.refresh(thread)
    return thread.id


def _single_result(transcript: str, out: dict) -> dict:
    return {
        "transcript": transcript,
        "thread_id": out.get("thread_id"),
        "answer": out.get("answer", ""),
        "citations": out.get("citations", []),
        "tool_trace": _tool_trace([out]),
        "expects_reply": bool(out.get("expects_reply")),
        "display": out.get("display"),
    }


# ── LLM planner (only for ambiguous multi-intent turns) ──────────────────────


async def _llm_plan_and_execute(
    db: AsyncSession,
    user: User,
    transcript: str,
    *,
    thread_id: str | None,
    content_id: str | None,
) -> dict | None:
    if db is None or not getattr(user, "id", None):
        return None

    llm = get_llm_adapter()
    tool_lines = "\n".join(f"- {t.name}: {t.description}" for t in REGISTRY)
    planner_system = (
        "You are OrbPlanner. Select tools for a spoken assistant turn.\n"
        'Return strict JSON: {"steps":[{"tool":"...","why":"..."}]}.\n'
        f"Allowed tools: {', '.join(t.name for t in REGISTRY)}.\n"
        "Use ask_briefly (the user's own sources) for open-ended questions — it is the default.\n"
        "Use web_search ONLY for explicit open-web requests or current external facts the corpus can't cover.\n"
        f"Max {_MAX_TOOL_STEPS} steps."
    )
    planner_user = f"User transcript: {transcript}\n\nTools:\n{tool_lines}"
    try:
        plan = await llm.complete_json(
            [Message(role="user", content=planner_user)],
            system=planner_system,
            max_tokens=220,
            user_id=user.id,
            agent="orb_planner",
        )
    except Exception as exc:  # noqa: BLE001
        log.debug("orb planner fallback: %s", exc)
        return None

    raw_steps = plan.get("steps") if isinstance(plan, dict) else None
    if not isinstance(raw_steps, list) or not raw_steps:
        return None

    steps: list[tuple[str, dict | None]] = []
    for step in raw_steps[:_MAX_TOOL_STEPS]:
        if not isinstance(step, dict):
            continue
        name = str(step.get("tool") or "").strip()
        if name in _BY_NAME:
            args = step.get("args") if isinstance(step.get("args"), dict) else None
            steps.append((name, args))
    if not steps:
        return None

    tool_outputs: list[dict] = []
    resolved_thread = thread_id
    for name, args in steps:
        out = await _exec_tool(_BY_NAME[name], db, user, transcript, resolved_thread, content_id, args)
        if out.get("thread_id"):
            resolved_thread = out["thread_id"]
        tool_outputs.append(out)

    if len(tool_outputs) == 1:
        only = tool_outputs[0]
        return {
            "thread_id": only.get("thread_id") or resolved_thread,
            "answer": only.get("answer", ""),
            "citations": only.get("citations", []),
            "tool_trace": _tool_trace(tool_outputs),
        }

    # Multiple tools → synthesize one concise spoken answer.
    synthesis_system = (
        "You are Briefly Orb. Synthesize multiple tool outputs into one concise spoken answer.\n"
        'Return strict JSON: {"answer":"..."}. Keep it practical and direct.'
    )
    synthesis_payload = {
        "user_query": transcript,
        "tool_outputs": [
            {"tool": o.get("tool"), "answer": o.get("answer", ""), "citations": o.get("citations", [])}
            for o in tool_outputs
        ],
    }
    final_answer = ""
    try:
        synth = await llm.complete_json(
            [Message(role="user", content=json.dumps(synthesis_payload, ensure_ascii=False))],
            system=synthesis_system,
            max_tokens=320,
            user_id=user.id,
            agent="orb_synthesizer",
        )
        if isinstance(synth, dict):
            final_answer = str(synth.get("answer") or "").strip()
    except Exception as exc:  # noqa: BLE001
        log.debug("orb synthesis fallback: %s", exc)
    if not final_answer:
        final_answer = " ".join(
            part for part in (str(o.get("answer", "")).strip() for o in tool_outputs) if part
        ).strip()
    return {
        "thread_id": resolved_thread,
        "answer": final_answer,
        "citations": _merge_citations(tool_outputs),
        "tool_trace": _tool_trace(tool_outputs),
    }


# ── Agent runtime (the live brain for tasks) ─────────────────────────────────
# A task — any act/write tool or a compound multi-tool goal — runs through the
# plan→execute→observe loop: it picks tools, chains them, and asks the user a
# follow-up only when information is genuinely missing. Quick single reads skip
# this (they go direct) so voice latency stays low.


def _agent_registry() -> ToolRegistry:
    registry = ToolRegistry([from_orb_tool(t) for t in REGISTRY])
    from briefly_api.agent.plugins import load_plugin_tools

    load_plugin_tools(registry)
    return registry


async def _persist_agent_run(
    user_id: str, goal: str, result, duration_ms: int
) -> None:
    """Write the audit record for an agent run on its own session, so auditing never
    affects or depends on the request transaction. Best-effort — never raises."""
    from briefly_api.db.models import AgentRun

    try:
        async with SessionLocal() as session:
            session.add(
                AgentRun(
                    user_id=user_id,
                    surface="orb",
                    goal=(goal or "")[:2000],
                    answer=(result.answer or "")[:4000],
                    tools_used=list(result.tools_used or []),
                    stopped_reason=result.stopped_reason,
                    steps=[s.to_dict() for s in result.steps],
                    thread_id=result.thread_id,
                    duration_ms=duration_ms,
                )
            )
            await session.commit()
    except Exception:
        log.exception("agent run audit persist failed for user %s", user_id)


async def _run_agent(
    db: AsyncSession,
    user: User,
    transcript: str,
    *,
    thread_id: str | None,
    content_id: str | None,
) -> dict | None:
    settings = get_settings()
    runtime = AgentRuntime(_agent_registry(), max_steps=settings.agent_max_steps, allow_writes=True)
    ctx = ToolContext(
        db=db,
        user=user,
        settings=settings,
        goal=transcript,
        thread_id=thread_id,
        content_id=content_id,
    )
    started = time.monotonic()
    try:
        result = await runtime.run(ctx)
    except Exception:
        log.exception("orb agent runtime failed — falling back")
        return None
    duration_ms = int((time.monotonic() - started) * 1000)

    await _persist_agent_run(user.id, transcript, result, duration_ms)

    answer = (result.answer or "").strip()
    if not answer:
        return None
    # The agent is waiting on the user if it asked a question or paused for confirmation.
    expects_reply = answer.endswith("?") or result.stopped_reason == "needs_confirmation"
    return {
        "thread_id": result.thread_id or thread_id,
        "answer": answer,
        "citations": result.citations,
        "tool_trace": [{"tool": s.tool, "ok": s.ok} for s in result.steps if s.tool],
        "expects_reply": expects_reply,
    }


# ── Public entrypoint ────────────────────────────────────────────────────────


def transcript_matches_wake_phrase(transcript: str) -> bool:
    """True when STT output contains the orb wake phrase (with common mis-hears)."""
    norm = re.sub(r"[^\w\s]", " ", (transcript or "").lower())
    norm = " ".join(norm.split())
    if not norm:
        return False
    phrases = (
        "hey briefly",
        "hi briefly",
        "hay briefly",
        "a briefly",
        "hey brief",
        "hi brief",
        "hey briefley",
        "hey brieflee",
        "hey breifly",
        "hey bri",
        "hi bri",
    )
    if any(p in norm for p in phrases):
        return True
    words = norm.split()
    for i, word in enumerate(words):
        if word in ("hey", "hi", "hay", "a") and "briefly" in words[i : i + 4]:
            return True
        if word in ("hey", "hi", "hay") and i + 1 < len(words) and words[i + 1].startswith("bri"):
            return True
    return False


def transcript_likely_wake_phrase(transcript: str) -> bool:
    """Fuzzy wake match for partial STT — avoids missing clipped wake phrases."""
    if transcript_matches_wake_phrase(transcript):
        return True
    norm = re.sub(r"[^\w\s]", " ", (transcript or "").lower())
    norm = " ".join(norm.split())
    if not norm or len(norm) > 32:
        return False
    if norm in ("briefly", "brieflee", "breifly", "briefley"):
        return True
    if norm.startswith("briefly ") and len(norm.split()) <= 3:
        return True
    if re.match(r"^(hey|hi|hay|a)\s+bri", norm):
        return True
    if "briefly" in norm.split() and len(norm.split()) <= 4:
        return True
    return False


async def check_wake_phrase(
    db: AsyncSession | None,
    user: User,
    *,
    audio_bytes: bytes,
    filename: str = "wake.webm",
    content_type: str = "audio/webm",
) -> dict:
    """Transcribe a short wake clip; STT only — no agent turn."""
    if not audio_bytes or len(audio_bytes) < 200:
        return {"transcript": "", "wake": False}
    from briefly_api.stt.wake_context import WAKE_STT_PROMPT

    stt = get_stt_adapter()
    context_prompt = WAKE_STT_PROMPT
    try:
        transcript = (
            await stt.transcribe(
                audio_bytes,
                filename=filename,
                content_type=content_type,
                context_prompt=context_prompt,
            )
        ).strip()
    except Exception as exc:
        log.warning("wake phrase STT failed: %s", exc)
        return {"transcript": "", "wake": False}
    wake = transcript_matches_wake_phrase(transcript) or transcript_likely_wake_phrase(
        transcript
    )
    return {
        "transcript": transcript,
        "wake": wake,
    }


async def run_orb_turn(
    db: AsyncSession,
    user: User,
    *,
    audio_bytes: bytes | None = None,
    filename: str = "speech.webm",
    content_type: str = "audio/webm",
    text: str | None = None,
    thread_id: str | None = None,
    content_id: str | None = None,
    session_id: str | None = None,
    surface: str = "desktop",
) -> dict:
    """
    One voice turn. Provide either spoken `audio_bytes` (transcribed first) or
    typed `text`. Returns the transcript plus a grounded answer + citations.
    """
    timings: dict[str, int] = {}
    started = time.monotonic()
    session: OrbSessionState | None = None
    if db is not None and getattr(user, "id", None):
        session = await resolve_session(
            user.id,
            session_id=session_id,
            thread_id=thread_id,
            surface=surface,
        )
        if session.thread_id and not thread_id:
            thread_id = session.thread_id

    transcript = (text or "").strip()

    if audio_bytes:
        if len(audio_bytes) < 400:
            raise ValueError("Recording too short — try again.")
        stt_started = time.monotonic()
        stt = get_stt_adapter()
        context_prompt = None
        if db is not None and getattr(user, "id", None):
            from briefly_api.stt.profile_context import transcription_prompt_for_orb_turn

            context_prompt = await transcription_prompt_for_orb_turn(
                db,
                user.id,
                session=session,
                thread_id=thread_id or (session.thread_id if session else None),
            )
        try:
            transcript = (
                await stt.transcribe(
                    audio_bytes,
                    filename=filename,
                    content_type=content_type,
                    context_prompt=context_prompt,
                )
            ).strip()
        except (httpx.HTTPStatusError, ValueError) as exc:
            if isinstance(exc, httpx.HTTPStatusError):
                log.warning(
                    "orb STT failed user=%s status=%s bytes=%d type=%s",
                    getattr(user, "id", None),
                    exc.response.status_code,
                    len(audio_bytes),
                    content_type,
                )
            else:
                log.warning(
                    "orb STT failed user=%s decode bytes=%d type=%s: %s",
                    getattr(user, "id", None),
                    len(audio_bytes),
                    content_type,
                    exc,
                )
            raise ValueError("Couldn't process that audio — please try again.") from exc
        timings["stt_ms"] = int((time.monotonic() - stt_started) * 1000)

    if not transcript:
        raise ValueError("No speech detected — try again.")

    route_started = time.monotonic()
    # ── Routing ──────────────────────────────────────────────────────────────
    if db is not None and getattr(user, "id", None):
        resolved_thread = thread_id or (session.thread_id if session else None)
        thread_msg_count = await _thread_message_count(db, user.id, resolved_thread)
        decision = await route_transcript(
            transcript,
            thread_message_count=thread_msg_count,
            session_thread_id=session.thread_id if session else None,
            session_has_prior_turn=bool(session and session.last_transcript),
        )
        timings["route_ms"] = int((time.monotonic() - route_started) * 1000)

        if decision.kind == "direct" and len(decision.tools) == 1:
            agent_started = time.monotonic()
            out = await _exec_tool(
                decision.tools[0], db, user, transcript, resolved_thread, content_id
            )
            timings["agent_ms"] = int((time.monotonic() - agent_started) * 1000)
            result = _single_result(transcript, out)
            persisted = await _persist_orb_exchange(
                db,
                user.id,
                out.get("thread_id") or resolved_thread,
                transcript,
                result.get("answer", ""),
                citations=result.get("citations") or [],
            )
            if persisted:
                result["thread_id"] = persisted
            result["session_id"] = session.session_id if session else None
            result["timings"] = timings
            if session:
                await update_session_after_turn(
                    session,
                    thread_id=result.get("thread_id"),
                    transcript=transcript,
                    draft_id=out.get("draft_id"),
                )
            return result

        if decision.kind == "agent":
            agent_started = time.monotonic()
            planned = await _run_agent(
                db, user, transcript, thread_id=thread_id, content_id=content_id
            )
            timings["agent_ms"] = int((time.monotonic() - agent_started) * 1000)
            if planned is not None:
                payload = {"transcript": transcript, **planned}
                payload["session_id"] = session.session_id if session else None
                payload["timings"] = timings
                if session:
                    await update_session_after_turn(
                        session,
                        thread_id=payload.get("thread_id"),
                        transcript=transcript,
                    )
                return payload
            planned = await _llm_plan_and_execute(
                db, user, transcript, thread_id=thread_id, content_id=content_id
            )
            if planned is not None:
                payload = {"transcript": transcript, **planned}
                payload["session_id"] = session.session_id if session else None
                payload["timings"] = timings
                if session:
                    await update_session_after_turn(
                        session,
                        thread_id=payload.get("thread_id"),
                        transcript=transcript,
                    )
                return payload

    # ── Default: straight to the brain (open questions, no context, fallthrough)
    agent_started = time.monotonic()
    result_data = await ask_briefly(
        db, user, transcript, thread_id=thread_id, content_id=content_id, voice=True
    )
    timings["agent_ms"] = int((time.monotonic() - agent_started) * 1000)
    assistant = result_data.get("assistant", {}) if isinstance(result_data, dict) else {}
    answer = assistant.get("content", "")
    payload = {
        "transcript": transcript,
        "thread_id": result_data.get("thread_id") if isinstance(result_data, dict) else None,
        "answer": answer,
        "citations": assistant.get("citations", []),
        "tool_trace": [{"tool": "ask_briefly"}],
        "expects_reply": bool(str(answer).strip().endswith("?")),
        "session_id": session.session_id if session else None,
        "timings": timings,
    }
    timings["total_ms"] = int((time.monotonic() - started) * 1000)
    if session:
        await update_session_after_turn(
            session,
            thread_id=payload.get("thread_id"),
            transcript=transcript,
        )
    return payload


def _orb_sse_event(payload: dict) -> str:
    return f"data: {json.dumps(payload, ensure_ascii=False)}\n\n"


async def iter_orb_text_turn_events(
    db: AsyncSession | None,
    user: User | None,
    transcript: str,
    *,
    user_id: str | None = None,
    thread_id: str | None = None,
    content_id: str | None = None,
    session: OrbSessionState | None = None,
    session_id: str | None = None,
    surface: str = "desktop",
    timings: dict[str, int] | None = None,
    started: float | None = None,
) -> AsyncIterator[dict]:
    """Stream structured turn events after transcript is known (HTTP SSE + WS)."""
    from briefly_api.services.ask_briefly import _load_user_for_ask

    timings = timings if timings is not None else {}
    started = started if started is not None else time.monotonic()
    resolved_thread = thread_id or (session.thread_id if session else None)
    uid = user_id or (str(user.id) if user and getattr(user, "id", None) else None)

    yield {
        "type": "meta",
        "transcript": transcript,
        "session_id": session.session_id if session else session_id,
        "thread_id": resolved_thread,
        "timings": timings,
    }

    if session:
        await update_session_after_turn(session, transcript=transcript)

    route_started = time.monotonic()
    stream_ask = False
    if uid:
        if db is not None and user is not None:
            thread_msg_count = await _thread_message_count(db, uid, resolved_thread)
            decision = await route_transcript(
                transcript,
                thread_message_count=thread_msg_count,
                session_thread_id=session.thread_id if session else None,
                session_has_prior_turn=bool(session and session.last_transcript),
            )
            timings["route_ms"] = int((time.monotonic() - route_started) * 1000)
            stream_ask = decision.kind == "ask_briefly" or (
                decision.kind == "direct"
                and len(decision.tools) == 1
                and decision.tools[0].name == "ask_briefly"
            )
            if not stream_ask:
                result = await run_orb_turn(
                    db,
                    user,
                    text=transcript,
                    thread_id=resolved_thread,
                    content_id=content_id,
                    session_id=session.session_id if session else session_id,
                    surface=surface,
                )
                timings["total_ms"] = int((time.monotonic() - started) * 1000)
                result["timings"] = {**result.get("timings", {}), **timings}
                yield {"type": "complete", **result}
                return
        else:
            async with SessionLocal() as route_db:
                route_user = await _load_user_for_ask(route_db, uid)
                thread_msg_count = await _thread_message_count(route_db, uid, resolved_thread)
                decision = await route_transcript(
                    transcript,
                    thread_message_count=thread_msg_count,
                    session_thread_id=session.thread_id if session else None,
                    session_has_prior_turn=bool(session and session.last_transcript),
                )
                timings["route_ms"] = int((time.monotonic() - route_started) * 1000)
                stream_ask = decision.kind == "ask_briefly" or (
                    decision.kind == "direct"
                    and len(decision.tools) == 1
                    and decision.tools[0].name == "ask_briefly"
                )
                if not stream_ask:
                    result = await run_orb_turn(
                        route_db,
                        route_user,
                        text=transcript,
                        thread_id=resolved_thread,
                        content_id=content_id,
                        session_id=session.session_id if session else session_id,
                        surface=surface,
                    )
                    timings["total_ms"] = int((time.monotonic() - started) * 1000)
                    result["timings"] = {**result.get("timings", {}), **timings}
                    yield {"type": "complete", **result}
                    return

    if not uid or not stream_ask:
        raise ValueError("Voice turn unavailable.")

    ask_user = user
    if ask_user is None:
        async with SessionLocal() as ask_db:
            ask_user = await _load_user_for_ask(ask_db, uid)

    stream_thread_id = resolved_thread
    answer_parts: list[str] = []
    citations: list = []
    async for event in iter_ask_briefly_events(
        None,
        ask_user,
        transcript,
        thread_id=stream_thread_id,
        content_id=content_id,
        voice=True,
    ):
        event_type = event.get("type")
        if event_type == "thread_id" and event.get("thread_id"):
            stream_thread_id = event["thread_id"]
            if session:
                session.thread_id = stream_thread_id
                await update_session_after_turn(session, thread_id=stream_thread_id)
            yield {
                "type": "meta",
                "transcript": transcript,
                "session_id": session.session_id if session else session_id,
                "thread_id": stream_thread_id,
                "timings": timings,
            }
        elif event_type == "delta":
            delta = str(event.get("content") or "")
            if delta:
                answer_parts.append(delta)
                yield {"type": "delta", "content": delta}
        elif event_type == "done":
            citations = event.get("citations") or []
            if event.get("answer"):
                answer_parts = [str(event["answer"])]

    answer = "".join(answer_parts).strip()
    timings["total_ms"] = int((time.monotonic() - started) * 1000)
    complete = {
        "type": "complete",
        "transcript": transcript,
        "thread_id": stream_thread_id,
        "session_id": session.session_id if session else session_id,
        "answer": answer,
        "citations": citations,
        "tool_trace": [{"tool": "ask_briefly"}],
        "expects_reply": bool(answer.endswith("?")),
        "timings": timings,
    }
    if session:
        await update_session_after_turn(
            session,
            thread_id=stream_thread_id,
            transcript=transcript,
        )
    yield complete


async def stream_orb_turn(
    db: AsyncSession,
    user: User,
    *,
    audio_bytes: bytes | None = None,
    filename: str = "speech.webm",
    content_type: str = "audio/webm",
    text: str | None = None,
    thread_id: str | None = None,
    content_id: str | None = None,
    session_id: str | None = None,
    surface: str = "desktop",
) -> AsyncIterator[str]:
    """
    SSE stream for a voice turn. Yields meta + LLM deltas for ask_briefly routes,
    or a single complete event for tool routes (client plays TTS after).
    """
    timings: dict[str, int] = {}
    started = time.monotonic()
    session: OrbSessionState | None = None
    if db is not None and getattr(user, "id", None):
        session = await resolve_session(
            user.id,
            session_id=session_id,
            thread_id=thread_id,
            surface=surface,
        )
        if session.thread_id and not thread_id:
            thread_id = session.thread_id

    transcript = (text or "").strip()

    if audio_bytes:
        if len(audio_bytes) < 400:
            raise ValueError("Recording too short — try again.")
        stt_started = time.monotonic()
        stt = get_stt_adapter()
        context_prompt = None
        if db is not None and getattr(user, "id", None):
            from briefly_api.stt.profile_context import transcription_prompt_for_orb_turn

            context_prompt = await transcription_prompt_for_orb_turn(
                db,
                user.id,
                session=session,
                thread_id=thread_id or (session.thread_id if session else None),
            )
        try:
            transcript = (
                await stt.transcribe(
                    audio_bytes,
                    filename=filename,
                    content_type=content_type,
                    context_prompt=context_prompt,
                )
            ).strip()
        except (httpx.HTTPStatusError, ValueError) as exc:
            if isinstance(exc, httpx.HTTPStatusError):
                log.warning(
                    "orb stream STT failed user=%s status=%s",
                    getattr(user, "id", None),
                    exc.response.status_code,
                )
            else:
                log.warning(
                    "orb stream STT failed user=%s decode: %s",
                    getattr(user, "id", None),
                    exc,
                )
            raise ValueError("Couldn't process that audio — please try again.") from exc
        timings["stt_ms"] = int((time.monotonic() - stt_started) * 1000)

    if not transcript:
        raise ValueError("No speech detected — try again.")

    async for event in iter_orb_text_turn_events(
        db,
        user,
        transcript,
        thread_id=thread_id or (session.thread_id if session else None),
        content_id=content_id,
        session=session,
        session_id=session_id,
        surface=surface,
        timings=timings,
        started=started,
    ):
        yield _orb_sse_event(event)
