"""Brief quality evaluation harness."""
